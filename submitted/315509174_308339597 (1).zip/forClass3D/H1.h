#include "H2.h"
class A
{
public:
	A();
};
