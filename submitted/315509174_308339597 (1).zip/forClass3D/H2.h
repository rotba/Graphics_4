#include "H1.h"
class B
{
public:
	B();
};
